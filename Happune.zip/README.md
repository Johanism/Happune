Tools Happune ini dibuat untuk pentester, bukan kejahatan.

Author : yallism.
Instagram : @ilannisme

Note: DILARANG COPY TOOLS INI!!!


Cara menggunakan :

1. pkg update & pkg upgrade
2. pkg install python3
3. pkg install git
4. git clone https://github.com/.../...
5. cd Happune
6. pkg install colorama
7. pkg install mpv
8. python Happune.py -s [Ip Target] -p [Saran: 80] -t [Saran: 135]

Dan Booom!!!!


Thanks sudah menggunakan tools ini, See you bro...
